#if defined(LEDA_INSTALL) && !defined(LEDA_STD_INCLUDE)
#error Please include <LEDA/std/header.h> instead of <header.h>
#endif

#include_next <stdarg.h>
