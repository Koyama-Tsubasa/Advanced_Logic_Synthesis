/*******************************************************************************
+
+  LEDA 5.2  
+
+
+  REDEFINE_NAMES.h
+
+
+  Copyright (c) 1995-2007
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/

// $Revision: 1.2 $  $Date: 2007/02/25 00:49:14 $

// for backward compatibility
// please use <LEDA/internal/PREAMBLE.h>

#include <LEDA/internal/PREAMBLE.h>

