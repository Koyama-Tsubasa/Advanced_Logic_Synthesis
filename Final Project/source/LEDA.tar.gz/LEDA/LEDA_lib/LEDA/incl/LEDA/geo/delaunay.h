/*******************************************************************************
+
+  LEDA 5.2  
+
+
+  delaunay.h
+
+
+  Copyright (c) 1995-2007
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/

// $Revision: 1.2 $  $Date: 2007/02/25 00:48:20 $


#include <LEDA/geo/float_delaunay.h>
#include <LEDA/geo/rat_delaunay.h>

