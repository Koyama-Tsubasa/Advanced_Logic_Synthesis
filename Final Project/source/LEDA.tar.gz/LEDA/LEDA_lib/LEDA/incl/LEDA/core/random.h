/*******************************************************************************
+
+  LEDA 5.2  
+
+
+  random.h
+
+
+  Copyright (c) 1995-2007
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/

// $Revision: 1.2 $  $Date: 2007/02/25 00:48:08 $


#include <LEDA/core/random_source.h>

