/*******************************************************************************
+
+  LEDA 5.2  
+
+
+  setjmp.h
+
+
+  Copyright (c) 1995-2007
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/

/* $Revision: 1.2 $  $Date: 2007/02/25 00:49:17 $ */

#define LEDA_STD_INCLUDE
#include <setjmp.h>
#undef LEDA_STD_INCLUDE
