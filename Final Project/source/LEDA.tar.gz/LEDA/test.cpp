#include <iostream>
#include <climits> // INT_MAX
using namespace std;

#include <LEDA/graph/graph.h>
#include <LEDA/graph/graph_alg.h>
#include <LEDA/graph/max_flow.h>
using namespace leda;

int main()
{
	// Graph construction
	graph G;
    node s = G.new_node();
    node a = G.new_node();
	node b = G.new_node();
	node c = G.new_node();
	node d = G.new_node();
	node e = G.new_node();
    node f = G.new_node();
    node g = G.new_node();
    node h = G.new_node();
    node t = G.new_node();
    node i = G.new_node();
	edge s_a = G.new_edge(s, a);
	edge s_b = G.new_edge(s, b);
	edge s_c = G.new_edge(s, c);
	edge s_d = G.new_edge(s, d);
	edge s_e = G.new_edge(s, e);
	edge a_f = G.new_edge(a, f);
	edge b_f = G.new_edge(b, f);
	edge b_g = G.new_edge(b, g);
	edge c_g = G.new_edge(c, g);
	edge d_h = G.new_edge(d, h);
	edge e_h = G.new_edge(e, h);
	edge f_t = G.new_edge(f, t);
	edge f_i = G.new_edge(f, i);
	edge g_i = G.new_edge(g, i);
	edge g_t = G.new_edge(g, t);
	edge h_t = G.new_edge(h, t);
	edge i_t = G.new_edge(i, t);



	// Assign edge cap
	edge_array<int> cap(G);
	edge_array<int> flow(G);
	cap[s_a] = INT_MAX;
	cap[s_b] = INT_MAX;
	cap[s_c] = INT_MAX;
	cap[s_d] = INT_MAX;
	cap[s_e] = INT_MAX;
	cap[a_f] = 3;
	cap[b_f] = 2;
	cap[b_g] = 2;
	cap[c_g] = 7;
	cap[d_h] = 5;
	cap[e_h] = 4;
	cap[f_t] = 3;
	cap[f_i] = 3;
	cap[g_t] = 2;
	cap[g_i] = INT_MAX;
	cap[h_t] = 3;
	cap[i_t] = INT_MAX;


	int max_flow = MAX_FLOW_T(G, s, t, cap, flow);
	cout << "The maxflow is: " << max_flow << endl;

	return 0;
}
